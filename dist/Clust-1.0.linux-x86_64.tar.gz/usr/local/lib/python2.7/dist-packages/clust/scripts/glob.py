logfile = ''
object_label_upper = 'Object'
object_label_lower = 'object'
outputwidth = 70


def set_logfile(val):
    global logfile
    logfile = val


def set_object_label_upper(val):
    global object_label_upper
    object_label_upper = val


def set_object_label_lower(val):
    global object_label_lower
    object_label_lower = val


def set_outputwith(val):
    global outputwidth
    outputwidth = val
